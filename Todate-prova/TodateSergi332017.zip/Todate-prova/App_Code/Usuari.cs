﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Usuari
/// </summary>
public class Usuari
{
    public string name;
    public string birthdate;
    public string img;
    public string sex;
    public string sexWanted;
    public string mail;
    public string pw;
    public string colour;
    public string typeOfHair;
    public string shape;
    public string[] tastes;
    public string sports;
    public string birthplace;
    public string ubication;
    public string religion;
    public string civilstatus;
    public string children;
    public string [] iv;

    public Usuari() {}
       
    
}